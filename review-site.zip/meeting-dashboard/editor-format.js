/* Keep the selected gallery format when opening the existing editor. */
if (new URLSearchParams(location.search).get("format") === "portrait") {
  document.getElementById("format").value = "1350";
}
