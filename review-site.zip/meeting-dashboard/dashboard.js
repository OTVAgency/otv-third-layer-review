/* Reuse the reviewed V03 creative data. Filters never change the original assets. */
(() => {
  const templates = window.TEMPLATE_DATA;
  const gallery = document.getElementById('gallery');
  const dialog = document.getElementById('preview-dialog');
  let audience = 'all';
  let format = 'square';
  let activeTemplate = null;

  function assetPath(template, extension) {
    return `../review-pack-v03/templates/${extension}/${template.id}-${template.layout}-${format}.${extension}`;
  }

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  }

  function renderGallery() {
    // General concepts suit either audience. Only the other industry's specific post is hidden.
    const visible = templates.filter(template => audience === 'all' ||
      (audience === 'remodelers' ? template.id !== '08' : template.id !== '07'));
    gallery.replaceChildren();
    visible.forEach(template => {
      const title = template.headline.replace(/\n/g, ' ');
      const tile = element('article', 'graphic-tile');
      const preview = element('button', 'graphic-image');
      preview.type = 'button';
      preview.setAttribute('aria-label', `Preview concept ${template.id}: ${title}`);
      const image = element('img');
      image.src = assetPath(template, 'png');
      image.alt = title;
      image.width = 1080;
      image.height = format === 'square' ? 1080 : 1350;
      image.loading = 'lazy';
      preview.append(image, element('span', 'view-label', 'PREVIEW ↗'));
      preview.addEventListener('click', () => openPreview(template));
      const metadata = element('div', 'tile-topline');
      metadata.append(element('span', '', `${template.id} / ${template.category.toUpperCase()}`), element('span', '', format === 'square' ? '1:1' : '4:5'));
      const actions = element('div', 'tile-actions');
      const edit = element('a', '', 'Edit concept ↗');
      edit.href = `editor.html?template=${template.id}&format=${format}`;
      const download = element('a', '', 'PNG ↓');
      download.href = assetPath(template, 'png');
      download.download = `${template.id}-${template.layout}-${format}.png`;
      actions.append(edit, download);
      tile.append(preview, metadata, element('h3', '', title), actions);
      gallery.append(tile);
    });
    const size = format === 'square' ? '1080 × 1080' : '1080 × 1350';
    document.getElementById('gallery-count').textContent = `${visible.length} concepts · ${size}${audience !== 'all' ? ' · Includes shared campaign concepts' : ''}`;
    document.querySelectorAll('[data-audience]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.audience === audience)));
    document.querySelectorAll('[data-format]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.format === format)));
  }

  function openPreview(template) {
    activeTemplate = template;
    document.getElementById('preview-label').textContent = `${template.id} / ${template.category.toUpperCase()}`;
    document.getElementById('preview-title').textContent = template.headline.replace(/\n/g, ' ');
    document.getElementById('preview-size').textContent = format === 'square' ? 'SQUARE / 1080 × 1080' : 'PORTRAIT / 1080 × 1350';
    const image = document.getElementById('preview-image');
    image.src = assetPath(template, 'png');
    image.alt = template.headline.replace(/\n/g, ' ');
    document.getElementById('preview-caption').value = template.caption;
    document.getElementById('copy-status').textContent = '';
    ['png', 'svg'].forEach(extension => {
      const link = document.getElementById(`download-${extension}`);
      link.href = assetPath(template, extension);
      link.download = `${template.id}-${template.layout}-${format}.${extension}`;
    });
    document.getElementById('edit-template').href = `editor.html?template=${template.id}&format=${format}`;
    dialog.showModal();
    document.body.style.overflow = 'hidden';
  }

  document.querySelectorAll('[data-audience]').forEach(button => button.addEventListener('click', () => {
    audience = button.dataset.audience;
    renderGallery();
  }));
  document.querySelectorAll('[data-format]').forEach(button => button.addEventListener('click', () => {
    format = button.dataset.format;
    renderGallery();
  }));
  document.querySelectorAll('[data-jump-audience]').forEach(button => button.addEventListener('click', () => {
    audience = button.dataset.jumpAudience;
    renderGallery();
    document.getElementById('graphics').scrollIntoView();
  }));
  document.getElementById('close-preview').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => { document.body.style.overflow = ''; });
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  document.getElementById('copy-caption').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(activeTemplate.caption);
      document.getElementById('copy-status').textContent = 'Caption copied. Booking placeholders still need review.';
    } catch {
      // Local file previews can block clipboard access. Keep manual copying available.
      const caption = document.getElementById('preview-caption');
      caption.focus();
      caption.select();
      document.getElementById('copy-status').textContent = 'Caption selected. Use Copy on your device.';
    }
  });
  renderGallery();
})();
