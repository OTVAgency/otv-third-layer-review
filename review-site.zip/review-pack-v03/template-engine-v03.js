/* Direction v03: one cobalt accent, dimensional cards, and licensed illustrative photography.
   Text and geometry remain editable. Embedded photos keep exports self-contained. */
(function(root){
 const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
 function renderTemplate(d,h=1080,overrides={}){
  const p={surface:'#f4f1e8',ink:'#171a18',accent:'#2442ee',...d.colors,...overrides};
  const c=p.ink,a=p.accent,s=p.surface,blue=a,white='#fffdf5',black='#171a18';
  const rect=(x,y,w,hh,fill,rx=0,stroke='none',sw=0)=>`<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx="${rx}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
  const text=(v,x,y,size=30,weight=400,fill=c,extra='')=>`<text x="${x}" y="${y}" font-family="Arial, Helvetica, sans-serif" font-size="${size}" font-weight="${weight}" fill="${fill}" ${extra}>${esc(v)}</text>`;
  const line=(x1,y1,x2,y2,color=c,sw=2)=>`<path d="M${x1} ${y1}L${x2} ${y2}" fill="none" stroke="${color}" stroke-width="${sw}"/>`;
  const circle=(x,y,r,fill,stroke='none',sw=0)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
  const arrow=(x,y,size,color=c)=>`<path d="M${x} ${y+size}L${x+size} ${y}M${x} ${y}H${x+size}V${y+size}" stroke="${color}" stroke-width="${size/7}" fill="none"/>`;
  const star=(x,y,r,fill)=>{let pts=[];for(let i=0;i<24;i++){const angle=i*Math.PI/12,rr=i%2?r*.78:r;pts.push((x+Math.cos(angle)*rr)+','+(y+Math.sin(angle)*rr));}return `<polygon points="${pts.join(' ')}" fill="${fill}"/>`;};
  const photo=(which,x,y,w,hh,clip)=>{const src=d.photos?.[which];if(!src)return rect(x,y,w,hh,a,16);return `<defs><clipPath id="${clip}"><rect x="${x}" y="${y}" width="${w}" height="${hh}" rx="16"/></clipPath></defs><image href="${src}" x="${x}" y="${y}" width="${w}" height="${hh}" preserveAspectRatio="xMidYMid slice" clip-path="url(#${clip})"/>`;};
  const ln=d.headline.split('\n'),max=Math.max(...ln.map(x=>x.length));
  const fs=Math.min(ln.length>3?84:110,Math.floor(1720/max));
  const top=211,sy=top+(ln.length-1)*fs*1.01+64;
  const y=Math.max(574,sy+d.support.split('\n').length*39+30),b=h-200,vh=b-y;
  let bg=rect(0,0,1080,h,s),art='',head='';
  if(d.id==='08'){
    bg+=photo('garden',0,0,1080,h,'fullGarden');
    bg+='<defs><linearGradient id="shade" x1="0" x2="0.2" y1="0" y2="1"><stop offset="0" stop-color="#171a18" stop-opacity=".94"/><stop offset=".6" stop-color="#171a18" stop-opacity=".48"/><stop offset="1" stop-color="#171a18" stop-opacity=".75"/></linearGradient></defs>'+rect(0,0,1080,h,'url(#shade)');
  }
  // The header tag and crop marks create an editorial frame across the whole set.
  const eyebrowFill=c;
  const eyebrow=rect(72,57,Math.min(850,d.eyebrow.length*14+50),52,'none',26,eyebrowFill,1.5)+text(d.eyebrow,94,90,20,700,eyebrowFill,'letter-spacing="1.1"')+text(d.id,956,91,25,700,eyebrowFill);
  ln.forEach((v,i)=>{
    const yy=top+i*fs*1.01;
    const last=i===ln.length-1;
    let fill=last?(['03','09'].includes(d.id)?white:(['02','05','08','10'].includes(d.id)?c:a)):c;
    if(d.id==='04'||d.id==='07'||d.id==='11')fill=c;
    if(last&&['03','09'].includes(d.id)) head+=rect(62,yy-fs*.83,Math.min(946,v.length*fs*.56+30),fs*1.05,black,8);
    head+=text(v,72,yy,fs,900,fill,'letter-spacing="-4"');
  });
  const support=d.support.split('\n').map((v,i)=>text(v,76,sy+i*39,30,400,c)).join('');
  if(d.layout==='statement'){
    art=rect(96,y+16,888,vh-12,blue,16)+photo('house',72,y,896,vh-8,'houseFrame');
    art+=star(910,y+70,88,blue)+arrow(876,y+35,64,white);
    art+=rect(94,b-56,370,35,white,17)+text('ILLUSTRATIVE STOCK PHOTO',110,b-32,19,700,black);
  }else if(d.layout==='contrast'){
    art+=`<g opacity=".2">${circle(820,y+vh*.48,Math.min(vh*.55,220),'none',white,2)}${circle(820,y+vh*.48,Math.min(vh*.4,170),'none',white,2)}</g>`;
    ['CLARITY','CREDIBILITY','ACTION'].forEach((v,i)=>{const yy=y+i*vh/3;const color=[white,blue,white][i],ink=i===1?white:black;art+=`<g transform="rotate(${[-3,2,-2][i]} 540 ${yy+vh/6})">${rect(86+i*30,yy+5,846-i*30,vh/3-12,color,9)}${text(v,118+i*30,yy+vh/6+18,Math.min(56,vh/4),900,ink)}${arrow(838,yy+20,38,ink)}</g>`;});
  }else if(d.layout==='flow'){
    ['INQUIRY','OWNER','FOLLOW-UP'].forEach((v,i)=>{const x=72+i*326,yy=y+Math.min(25,vh*.08)*i,hh=vh-50;
      art+=rect(x+9,yy+10,280,hh,black,16)+rect(x,yy,280,hh,[white,blue,white][i],16,i===1?'none':black,1.5);
      const col=i===1?white:black;
      art+=circle(x+48,yy+48,23,col)+text(String(i+1),x+40,yy+57,25,700,i===1?blue:white)+text(v,x+22,yy+hh-28,29,900,col);
      if(i<2)art+=arrow(x+208,yy+65,42,col);
    });
  }else if(d.layout==='checklist'){
    art+=star(940,210,58,blue)+text('5',921,232,58,900,white);
    const list=['Services still match','Your best work is visible','A clear next step','Mobile feels easy','Every inquiry has an owner'];
    const step=vh/5;list.forEach((v,i)=>{const yy=y+i*step;art+=rect(72,yy,936,step-9,i===4?blue:black,8)+text('0'+(i+1),92,yy+step*.67,30,700,white)+text(v,160,yy+step*.67,31,700,white)+circle(960,yy+step*.44,12,'none',white,2);});
  }else if(d.layout==='pillars'){
    [['OFFER','What you do'],['ACTION','What comes next'],['OWNER','Who responds']].forEach((v,i)=>{const x=72+i*326,yy=y+30-i*15,col=[white,blue,white][i],ink=i===1?white:black;art+=rect(x,yy,284,vh-30+i*15,col,16)+text('0'+(i+1),x+24,yy+62,38,900,ink)+text(v[0],x+24,b-68,43,900,ink)+text(v[1],x+24,b-30,24,400,ink);});
  }else if(d.layout==='layers'){
    const hh=vh*.48;
    [['BRAND',white,black],['WEBSITE',black,white],['FOLLOW-UP',blue,white]].forEach((row,i)=>{const xx=72+i*140,yy=y+i*(vh-hh)/2;art+=rect(xx+10,yy+12,640,hh,black,22)+rect(xx,yy,640,hh,row[1],22,i===0?black:'none',1.5)+text(row[0],xx+32,yy+52,42,900,row[2])+arrow(xx+548,yy+22,36,row[2]);});
  }else if(d.layout==='architecture'){
    art+=photo('house',72,y,936,vh,'architecturePhoto');
    art+=`<g transform="rotate(-6 716 ${y+42})">${rect(472,y+7,510,76,blue,0)}${text('BUILT TO BE SEEN',498,y+59,37,900,white)}</g>`;
    art+=rect(88,b-49,350,33,black,16)+text('ILLUSTRATIVE STOCK PHOTO',105,b-26,18,700,white);
  }else if(d.layout==='landscape'){
    art+=circle(781,y+vh*.5,Math.min(vh*.4,170),'none',white,3)+circle(781,y+vh*.5,Math.min(vh*.3,130),'none',white,1.5)+arrow(720,y+vh*.5-60,118,white);
    art+=rect(76,b-43,350,34,black,17)+text('ILLUSTRATIVE STOCK PHOTO',94,b-20,18,700,white);
  }else if(d.layout==='review'){
    art+=rect(87,y+14,916,vh-12,black,22)+rect(72,y,916,vh-12,white,22,black,1.5);
    art+=text('15-20',100,y+Math.min(150,vh*.5),Math.min(140,vh*.48),900,black)+text('MINUTES. ONE CLEAR NEXT STEP.',106,y+Math.min(192,vh*.63),25,700,blue);
    art+=star(860,y+vh*.42,Math.min(94,vh*.3),blue)+arrow(827,y+vh*.42-35,64,white);
    art+=text('Your priorities. Your process. Your next project.',106,b-35,29,400,black);
  }else if(d.layout==='choice'){
    const labels=['IDENTITY','WEBSITE','INQUIRY PATH'];labels.forEach((v,i)=>{const yy=y+i*vh/3;const col=[black,blue,black][i],ink=white;art+=`<g transform="rotate(${[-2,1,-1][i]} 540 ${yy+vh/6})">${rect(86,yy+4,904,vh/3-12,col,40,i===1?'none':white,1.5)}${circle(132,yy+vh/6,15,'none',ink,3)}${text(v,180,yy+vh/6+16,44,900,ink)}${arrow(902,yy+vh/6-20,40,ink)}</g>`;});
  }else if(d.layout==='offer'){
    art+=rect(72,y,936,vh,black,22)+text('$7,500',102,y+Math.min(145,vh*.48),Math.min(150,vh*.51),900,white)+text('PROPOSED PROJECT INVESTMENT',106,y+Math.min(188,vh*.65),24,700,white);
    art+=star(894,y+86,67,blue)+arrow(867,y+57,54,white);
    art+=text('5 PAGES MAX  /  1 TOOL  /  UP TO 2 WORKFLOWS',106,b-58,28,700,white)+text('Software separate. Scope confirmed after discovery.',106,b-22,23,400,white);
  }else if(d.layout==='packages'){
    const rows=[['Launch Ready','$5,000','BRAND REFRESH + WEBSITE'],['Lead Flow','$7,500','WEBSITE + INQUIRY PROCESS'],['Signature Launch','$10,000','IDENTITY + WEBSITE + TEMPLATES']];
    rows.forEach((r,i)=>{const yy=y+i*vh/3,col=i===1?blue:white,ink=i===1?white:black;art+=rect(72,yy,936,vh/3-10,col,12,i===1?'none':black,1.5)+text(r[0],100,yy+40,32,900,ink)+text(r[1],814,yy+40,35,900,ink)+text(r[2],102,yy+69,19,700,ink);});
  }
  const footerFill=blue;
  const footerInk=white;
  const footer=rect(72,h-139,936,78,footerFill,39)+text(d.cta,104,h-90,29,700,footerInk)+arrow(934,h-117,34,footerInk);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="${h}" viewBox="0 0 1080 ${h}" role="img" aria-label="${esc(d.headline.replaceAll('\n',' '))}"><title>${esc(d.headline.replaceAll('\n',' '))}</title>${bg}${eyebrow}${head}${support}${art}${footer}</svg>`;
 }
 root.renderTemplate=renderTemplate;if(typeof module!=='undefined')module.exports={renderTemplate};
})(typeof window!=='undefined'?window:globalThis);
