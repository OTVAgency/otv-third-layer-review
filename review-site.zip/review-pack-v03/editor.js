/* Local editing only. Downloads preserve edits without sending data anywhere. */
const originals = window.TEMPLATE_DATA;
const working = structuredClone(originals);
const $ = id=>document.getElementById(id);
const picker=$('template');
const requested = new URLSearchParams(location.search).get('template');
if(originals.some(d=>d.id===requested)) picker.value=requested;
let current;
function download(content,name,type){
  const blob=new Blob([content],{type});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');link.href=url;link.download=name;link.click();
  setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function select(){
  current=working.find(d=>d.id===picker.value);
  ['headline','support','cta'].forEach(id=>$(id).value=current[id]);
  $('surface').value=current.colors?.surface||(current.theme==='ink'?'#202622':'#f2efe7');
  $('ink').value=current.colors?.ink||(current.theme==='ink'?'#f2efe7':'#202622');
  $('accent').value=current.colors?.accent||(current.theme==='ink'?'#c5b6a2':'#76634f');
  $('caption').textContent=current.caption;$('brief').textContent=current.visual;
  update();
}
function update(){
  ['headline','support','cta'].forEach(id=>current[id]=$(id).value);
  current.colors={surface:$('surface').value,ink:$('ink').value,accent:$('accent').value};
  $('preview').innerHTML=renderTemplate(current,Number($('format').value),current.colors);
  const warnings=[];
  if(current.headline.split('\n').length>4) warnings.push('Use four headline lines or fewer.');
  if(current.support.split('\n').length>2) warnings.push('Use two supporting lines or fewer.');
  const textNodes=$('preview').querySelectorAll('text');
  for(const el of textNodes){const box=el.getBBox();if(box.x+box.width>1006){warnings.push('Some text is too wide. Shorten it before export.');break;}}
  if(current.cta.length>48) warnings.push('Shorten the call to action.');
  $('warning').textContent=warnings.join(' ');
  $('svg').disabled=$('png').disabled=warnings.length>0;
}
picker.addEventListener('change',select);
['headline','support','cta','surface','ink','accent','format'].forEach(id=>$(id).addEventListener('input',update));
$('reset').addEventListener('click',()=>{const index=working.findIndex(d=>d.id===picker.value);working[index]=structuredClone(originals[index]);select();});
$('svg').addEventListener('click',()=>download(renderTemplate(current,Number($('format').value),current.colors),`template-${current.id}-${$('format').value}-edited.svg`,'image/svg+xml'));
$('data').addEventListener('click',()=>download(JSON.stringify(working,null,2),'template-copy-edited.json','application/json'));
$('png').addEventListener('click',async()=>{
  const svg=renderTemplate(current,Number($('format').value),current.colors);
  const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));
  const img=new Image();
  img.onload=()=>{const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=Number($('format').value);canvas.getContext('2d').drawImage(img,0,0);canvas.toBlob(blob=>{if(blob) download(blob,`template-${current.id}-${$('format').value}-edited.png`,'image/png');},'image/png');URL.revokeObjectURL(url);};
  img.onerror=()=>{$('warning').textContent='The PNG export could not be created. Download the SVG instead.';URL.revokeObjectURL(url);};
  img.src=url;
});
select();
